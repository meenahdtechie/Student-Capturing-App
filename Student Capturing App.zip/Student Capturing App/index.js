 let result = document.getElementById('track');


 let saveElement = document.getElementById('save-el')

 let counter = 0

 function increment() {
    counter += 1
    result.textContent = counter
    console.log (counter)
 }

 increment()

 function decrement() {
    let newCounter = counter--
    result.textContent =counter
 }

 decrement();

 function save() {
    let  tapping = counter + " - " 
    saveElement.textContent += tapping
    result.textContent = 0
    counter = 0


    console.log(counter)
 }

 save();